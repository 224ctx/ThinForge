#include "config.hpp"
#include "version.hpp"

namespace ezio
{

void config::parse_from_argv(int argc, char **argv)
{
	// clang-format off
	bpo::options_description desc("Allowed Options");
	desc.add_options()
		("help,h", "some help")
		("file,F", bpo::bool_switch(&file_flag)->default_value(false), "read data from file rather than raw disk")
		("listen,l", bpo::value<std::string>(&listen_address), "gRPC service listen address and port, default is 127.0.0.1:50051")
		("cache-size", bpo::value<int>(&cache_size_mb)->default_value(512), "unified cache size in MB, default is 512")
		("aio-threads", bpo::value<int>(&aio_threads)->default_value(16), "number of threads for disk I/O and hashing, default is 16")
		("slow-start", bpo::bool_switch(&slow_start)->default_value(false), "enable session-wide slow-start upload ramp (default off)")
		("slow-start-period", bpo::value<int>(&slow_start_period)->default_value(10), "slow-start step period in seconds (default 10)")
		("port,p", bpo::value<int>(&bt_listen_port)->default_value(0), "BitTorrent peer listen port (default 6881)")
		("enable-dht", bpo::bool_switch(&dht)->default_value(false), "enable DHT (default off)")
		("enable-lsd", bpo::bool_switch(&lsd)->default_value(false), "enable Local Service Discovery (default off)")
		("version,v", "show version")
	;
	// clang-format on

	// clang-format off
	bpo::variables_map vmap;
	bpo::store(bpo::command_line_parser(argc, argv)
		.options(desc)
		.run(),
		vmap);
	bpo::notify(vmap);
	// clang-format on

	if (vmap.count("help")) {
		std::cout << desc << std::endl;
		exit(0);
	}

	if (vmap.count("version")) {
		std::cout << "ezio " << EZIO_VERSION << std::endl;
		exit(0);
	}
}

}  // namespace ezio
